package com.miu.fpp.lessonSix.p2.q6;

public class Main {
    public static void main(String[] args) {

    }
}
