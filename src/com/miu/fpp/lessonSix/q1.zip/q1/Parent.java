package com.miu.fpp.lessonSix.q1;

public class Parent {
    void myMethod() {
        System.out.println("super class");
    }
}
