package com.miu.fpp.lessonSix.q1;

public class Derived extends Parent {
    void myMethod() {
        System.out.println("derived class");
    }

    public static void main(String[] args) {
//        Derived object =  new Parent();
//        object.myMethod();
    }

}
