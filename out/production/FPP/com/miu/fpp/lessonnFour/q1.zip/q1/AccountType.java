package com.miu.fpp.lessonnFour.q1;

public enum AccountType {
    CHECKING,
    SAVINGS,
    RETIREMENT;
}
